open_weather_token = '6b5e304be9e747c2293c99ce1941d06f'
tg_bot_token = '5534124405:AAFDfqwiHAU5aBcEmKBhTSBZtWC9552tfJM'
